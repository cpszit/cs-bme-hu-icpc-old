If you experience 
problems, you might find the solution in the README or 
in the <a href=http://gallery.sourceforge.net/faq.php>
FAQ</a>.  If not, you can ask for help on the <a href=http://sourceforge.net/mail/?group_id=7130>
Gallery Users Mailing List</a>.
