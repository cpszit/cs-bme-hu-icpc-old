#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>


int defold(char *in,char *out,char *end)
{
  char *outstart=out;
  while (in<end)
    {
       if (isdigit(*in))
	{
	  int times=atoi(in);
	  while (isdigit(*in)) in++;
	  if (*in!='(')
	    {
	      printf("WRONG\n( expected.\n");
	      return 0;
	    }
	  *in++;
	  char *start=in;
	  int par=1;
	  for (;;)
	    {
	      if (in==end)
		{
		  printf("WRONG\nMatching ) not found.\n");
		  return 0;
		}
	      if (*in=='(') par++;
	      if (*in==')')
		{
		  par--;
		  if (!par) break;
		}
	      in++;
	      
	    }
	  for (;times>0;times--)
	    {
	      out+=defold(start,out,in);
	    }
	  in++;
	}
      else
	{
	  //	  printf("(%c)",*in);
	  *out++=*in++;
	}
    }
  return out-outstart;
}
int main(int argc,char **argv)
{
  int i,j,d,k,n,m;
  if (argc!=4)
    {
      printf("Incorrect number of arguments!\n");
      return -1;
    }
  
  FILE *in,*sol,*hint;
  in=fopen(argv[1],"r");
  if (!in)
    {
      printf("Cannot open input file! (%s)\n",argv[1]);
      return -1;
    }
  sol=fopen(argv[2],"r");
  if (!sol)
    {
      printf("Cannot open contestant output file! (%s)\n",argv[2]);
      return -1;
    }
  hint=fopen(argv[3],"r");
  if (!hint)
    {
      printf("Cannot open hint file! (%s)\n",argv[3]);
      return -1;
    }
  char instr[4000], hstr[4000],solstr[4000];
  char hstr2[4000],solstr2[4000];
  char *p;
  for (;;)
    {
      fgets(instr,4000,in);
      if (instr[0]=='0') break;
      fgets(hstr,4000,hint);
      if (!fgets(solstr,4000,sol))
	{
	  printf("WRONG\nLine expected.\n");
	  return 0;
	}
      for (p=hstr;*p&&!isspace(*p);p++);
      int hlen=p-hstr;
      int hlend=defold(hstr,hstr2,p);
      hstr2[hlend]=0;
      for (p=solstr;*p&&!isspace(*p);p++);
      int slen=p-solstr;
      int slend=defold(solstr,solstr2,p);
      solstr2[slend]=0;
      //      printf("{%s}{%s}\n",hstr2,solstr2);
      if (slend==0)
	{
	  return 0;
	}
      if (slend!=hlend)
	{
	  printf("WRONG\nDecoded length error: %d != %d\n",slend,hlend);
	  return 0;
	}
      for (int i=0;i<hlend;i++)
	{
	  if (solstr2[i]!=hstr2[i])
	    {
	      printf("WRONG\nDecoded string is incorrect: '%c' != '%c'\n",solstr2[i],hstr2[i]);
	      return 0;
	    }
	}
      if (slen>hlen)
	{
	  printf("WRONG\nFolding is not optimal: %d > %d\n",slen,hlen);
	  return 0;
	}
      
    }
  int c;
  while ( (c=fgetc(sol))!=EOF)
    {
      if (!isspace(c))
	{
	  printf("WRONG\nTrailing garbage.\n");
	  return 0;
	}
    }
  printf("OK\n");
  return 0;
}
