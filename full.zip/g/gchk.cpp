#include <stdio.h>
#include <math.h>
#include <ctype.h>

int main(int argc,char **argv)
{
  if (argc!=4)
    {
      printf("Incorrect number of arguments!\n");
      return -1;
    }
  
  FILE *in,*sol,*hint;
  in=fopen(argv[1],"r");
  if (!in)
    {
      printf("Cannot open input file! (%s)\n",argv[1]);
      return -1;
    }
  sol=fopen(argv[2],"r");
  if (!in)
    {
      printf("Cannot contestant output file! (%s)\n",argv[2]);
      return -1;
    }
  hint=fopen(argv[3],"r");
  if (!in)
    {
      printf("Cannot open hint file! (%s)\n",argv[3]);
      return 0;
    }
  for (;;)
    {
      double t;
      if (fscanf(hint,"%lf",&t)!=1) break;
      //      printf("%.6f\n",t);
      double t2;
      if (fscanf(sol,"%lf",&t2)!=1)
	{
	  printf("WRONG\nExpected: %f, not found.\n",t);
	  return 0;
	}
      //printf("%f %f %f\n",t,t2,fabs(t-t2));
      if (fabs(t-t2)>0.000011)
	{
	  printf("WRONG\nExpected: %f, found: %f, difference: %f\n",t,t2,fabs(t-t2));
	  return 0;
	}
	
    }
  int c;
  while ( (c=fgetc(sol))!=EOF)
    {
      if (!isspace(c))
	{
	  printf("WRONG\nTrailing garbage.\n");
	  return 0;
	}
    }
  printf("OK\n");

}
