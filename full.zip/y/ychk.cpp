#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>

int main(int argc,char **argv)
{
  if (argc!=4)
    {
      printf("Incorrect number of arguments!\n");
      return -1;
    }
  
  FILE *in,*sol,*hint;
  in=fopen(argv[1],"r");
  if (!in)
    {
      printf("Cannot open input file! (%s)\n",argv[1]);
      return -1;
    }
  sol=fopen(argv[2],"r");
  if (!in)
    {
      printf("Cannot contestant output file! (%s)\n",argv[2]);
      return -1;
    }
  for (;;)
    {
      int t;
      if (fscanf(in,"%d",&t)!=1) break;
      //      printf("%.6f\n",t);
      if (!t) break;
      int t2;
      char buf[4000];
      if (!fgets(buf,4000,sol))
	{
	  printf("WRONG\nRead error.\n");
	  return 0;
	}
      int isprime=1;
      for (int i=2;i<t;i++)
	{
	  if (t%i==0)
	    {
	      isprime=0;
	      break;
	    }
	}
      if (isprime)
	{
	  if (strcmp(buf,"No solution.\n"))
	    {
	      printf("WRONG\n'No solution.' expected for %d.\n",t);
	      return 0;
	    }
	}
      else
	{
	  for (char *p=buf;*p;p++)
	    {
	      if (!isspace(*p) && !isdigit(*p))
		{
		  printf("WRONG\nNumberic answer expected for %d\n",t);
		  return 0;
		}
	    }
	  t2=atoi(buf);
	  if (t2<1 || t2>=t-1 || (t%(t2+1)) )
	    {
	      printf("WRONG\nIncorrect answer %d for %d\n",t2,t2);
	      return 0;
	    }
	  //	  printf("%d %d\n",t,t2);
	}
    }
  int c;
  while ( (c=fgetc(sol))!=EOF)
    {
      if (!isspace(c))
	{
	  printf("WRONG\nTrailing garbage.\n");
	  return 0;
	}
    }
  printf("OK\n");

}
